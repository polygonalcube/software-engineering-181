public class Banana implements Fruit {

    @Override
    public boolean hasSeeds() {
        return false;
    }
}
