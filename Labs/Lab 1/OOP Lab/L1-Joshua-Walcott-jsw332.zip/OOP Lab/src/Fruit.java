public interface Fruit {

    boolean hasSeeds();
}
