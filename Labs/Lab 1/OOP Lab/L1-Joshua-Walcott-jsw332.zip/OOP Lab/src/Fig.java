public class Fig implements Fruit {

    @Override
    public boolean hasSeeds() {
        return false;
    }
}