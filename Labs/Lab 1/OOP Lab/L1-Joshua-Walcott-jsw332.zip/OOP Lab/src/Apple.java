public class Apple implements Fruit {

    @Override
    public boolean hasSeeds() {
        return true;
    }
}
