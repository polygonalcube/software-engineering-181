public class Test {

    public static void main(String[] args) {
        if (true) {
            System.out.println("true");
        }
    }

    public void test() {
    }
}
