public class Square extends Rectangle {

    Square(int sideSize) {
        super(sideSize, sideSize);
    }
}
